Copy resources to this directory based on environment
https://github.com/shuzijun/leetcode-editor/releases/